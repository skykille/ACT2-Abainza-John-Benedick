<?php
require_once __DIR__.'/includes/auth.php'; require_role('student');
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('organizations.php');
$id=(int)($_POST['organization_id']??0); $orgs=read_data(ORGS_FILE); $org=null;
foreach($orgs as $o) if($o['id']===$id) $org=$o;
if(!$org){set_flash('Organization not found.','error');redirect('organizations.php');}
$apps=read_data(APPS_FILE);
foreach($apps as $a) if($a['student_id']===current_user()['id'] && $a['organization_id']===$id && in_array($a['status'],['Pending','Approved'])) {set_flash('You already have an active application for this organization.','error');redirect('organizations.php');}
$apps[]=['id'=>next_id($apps),'student_id'=>current_user()['id'],'student_name'=>current_user()['name'],'organization_id'=>$id,'organization_name'=>$org['name'],'status'=>'Pending','applied_at'=>date('c'),'reviewed_at'=>null,'admin_note'=>''];
write_data(APPS_FILE,$apps); set_flash('Membership application submitted.'); redirect('my_applications.php');
