# Student Organization Membership Management System (MySQL version)

## Requirements
- XAMPP (Apache + MySQL/MariaDB)
- PHP 8.0+ with PDO MySQL enabled
- phpMyAdmin (included with XAMPP)

## Install with XAMPP
1. Extract `Student_system` into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Select **Import**, choose the included `database.sql`, then click **Go**.
   This creates the `student_system` database and imports your existing JSON records.
5. Check `config/config.php`. Defaults: host `127.0.0.1`, port `3306`, database `student_system`, user `root`, blank password. Change if needed.
6. Open `http://localhost/Student_system/`.

## Existing data
The SQL import contains all supplied users, organizations, and applications. Existing password hashes are retained, so existing account passwords do not need to be reset.
- Admin email: `admin@school.edu`
- Admin password: `Admin123!` (change this after first login)
- Student accounts from the original JSON file are also imported.

## Database tables
- `users` — administrator and student accounts
- `organizations` — organization records
- `applications` — membership applications and review statuses

Original `data/*.json` files are retained as a backup. The application now reads and writes MySQL.

## Important
Back up your database before re-importing `database.sql`; importing it again can duplicate existing rows. Do not publish database credentials.
