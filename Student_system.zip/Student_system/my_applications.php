<?php
require_once __DIR__.'/includes/functions.php'; require_role('student');
$mine=array_filter(read_data(APPS_FILE),fn($a)=>$a['student_id']===current_user()['id']);
layout_start('My Applications'); ?>
<div class="panel table-wrap"><table><thead><tr><th>Organization</th><th>Date applied</th><th>Status</th><th>Admin note</th></tr></thead><tbody>
<?php foreach($mine as $a): ?><tr><td><?=e($a['organization_name'])?></td><td><?=e(date('M d, Y',strtotime($a['applied_at'])))?></td><td><span class="tag <?=strtolower(e($a['status']))?>"><?=e($a['status'])?></span></td><td><?=e($a['admin_note'])?></td></tr><?php endforeach; ?>
<?php if(!$mine) echo '<tr><td colspan="4">You have not submitted any applications.</td></tr>'; ?>
</tbody></table></div><?php layout_end(); ?>
