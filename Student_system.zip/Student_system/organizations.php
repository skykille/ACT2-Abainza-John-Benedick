<?php
require_once __DIR__.'/includes/auth.php'; require_login();
$orgs=read_data(ORGS_FILE); $u=current_user();
if($u['role']==='admin' && $_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action']??'';
    if($action==='add') {
        $name=trim($_POST['name']??''); $desc=trim($_POST['description']??''); $cat=trim($_POST['category']??'');
        if($name!=='') { $orgs[]= ['id'=>next_id($orgs),'name'=>$name,'description'=>$desc,'category'=>$cat,'status'=>'Active']; write_data(ORGS_FILE,$orgs); set_flash('Organization added.'); }
    } elseif($action==='delete') {
        $id=(int)($_POST['id']??0); $orgs=array_values(array_filter($orgs,fn($o)=>$o['id']!==$id)); write_data(ORGS_FILE,$orgs); set_flash('Organization deleted. Existing application records are retained.','success');
    }
    redirect('organizations.php');
}
layout_start('Organizations');
if($u['role']==='admin'): ?>
<form method="post" class="panel"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="add"><h2>Add organization</h2><div class="form-grid"><div><label>Name</label><input name="name" required></div><div><label>Category</label><input name="category" placeholder="Academic, Sports, Service..."></div></div><label>Description</label><textarea name="description" rows="3"></textarea><button class="btn">Add organization</button></form>
<?php endif; ?>
<div class="cards">
<?php foreach($orgs as $o): ?><article class="panel"><span class="tag"><?=e($o['category'])?></span><h2><?=e($o['name'])?></h2><p><?=e($o['description'])?></p>
<?php if($u['role']==='student'): ?>
<?php $already=false; foreach(read_data(APPS_FILE) as $a) if($a['student_id']===$u['id'] && $a['organization_id']===$o['id'] && in_array($a['status'],['Pending','Approved'])) $already=true; ?>
<form method="post" action="apply.php"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="organization_id" value="<?=e($o['id'])?>"><button class="btn" <?= $already?'disabled':'' ?>><?=$already?'Already applied / member':'Apply for membership'?></button></form>
<?php else: ?><form method="post" onsubmit="return confirm('Delete this organization?')"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=e($o['id'])?>"><button class="btn danger">Delete</button></form><?php endif; ?>
</article><?php endforeach; ?>
</div>
<?php layout_end(); ?>
