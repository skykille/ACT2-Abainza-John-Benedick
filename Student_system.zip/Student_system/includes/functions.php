<?php
require_once __DIR__ . '/../config/config.php';
if (session_status() === PHP_SESSION_NONE) session_start();

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (PDOException $ex) {
        http_response_code(500);
        exit('Database connection failed. Start Apache and MySQL in XAMPP, import database.sql in phpMyAdmin, then check config/config.php.');
    }
    return $pdo;
}

function table_for_file(string $file): string {
    $map = [USERS_FILE => 'users', ORGS_FILE => 'organizations', APPS_FILE => 'applications'];
    if (!isset($map[$file])) throw new InvalidArgumentException('Unknown data collection.');
    return $map[$file];
}

function read_data(string $file): array {
    $table = table_for_file($file);
    $rows = db()->query("SELECT * FROM `$table` ORDER BY id")->fetchAll();
    foreach ($rows as &$row) {
        if (isset($row['id'])) $row['id'] = (int)$row['id'];
        if (isset($row['organization_id'])) $row['organization_id'] = (int)$row['organization_id'];
        if ($table === 'applications' && isset($row['student_id'])) $row['student_id'] = (int)$row['student_id'];
        if ($table === 'users') $row['student_id'] = (string)($row['student_id'] ?? '');
    }
    unset($row);
    return $rows;
}

function write_data(string $file, array $data): bool {
    $table = table_for_file($file);
    $columns = [
        'users' => ['id','name','email','password','role','student_id','course','year_level','created_at'],
        'organizations' => ['id','name','description','category','status'],
        'applications' => ['id','student_id','student_name','organization_id','organization_name','status','applied_at','reviewed_at','admin_note'],
    ][$table];
    $pdo = db();
    try {
        $pdo->beginTransaction();
        $pdo->exec("DELETE FROM `$table`");
        if ($data) {
            $quoted = implode(',', array_map(fn($c) => "`$c`", $columns));
            $marks = implode(',', array_fill(0, count($columns), '?'));
            $stmt = $pdo->prepare("INSERT INTO `$table` ($quoted) VALUES ($marks)");
            foreach (array_values($data) as $row) {
                $values = [];
                foreach ($columns as $column) $values[] = $row[$column] ?? null;
                $stmt->execute($values);
            }
        }
        $pdo->commit();
        return true;
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $ex;
    }
}

function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function redirect(string $path): never { header('Location: ' . $path); exit; }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!current_user()) redirect('login.php'); }
function require_role(string $role): void {
    require_login();
    if (current_user()['role'] !== $role) { http_response_code(403); exit('Access denied.'); }
}
function set_flash(string $message, string $type='success'): void { $_SESSION['flash'] = ['message'=>$message,'type'=>$type]; }
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f=$_SESSION['flash']; echo '<div class="alert '.e($f['type']).'">'.e($f['message']).'</div>';
        unset($_SESSION['flash']);
    }
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Invalid form token. Please go back and try again.');
    }
}
function next_id(array $items): int { return empty($items) ? 1 : max(array_column($items, 'id')) + 1; }
function layout_start(string $title): void {
    $u=current_user();
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).' | '.APP_NAME.'</title><link rel="stylesheet" href="assets/style.css"></head><body>';
    echo '<header class="topbar"><a class="brand" href="dashboard.php">'.APP_NAME.'</a><nav>';
    if ($u) {
        echo '<a href="dashboard.php">Dashboard</a>';
        if ($u['role']==='admin') echo '<a href="organizations.php">Organizations</a><a href="applications.php">Applications</a><a href="students.php">Students</a>';
        else echo '<a href="organizations.php">Organizations</a><a href="my_applications.php">My Applications</a>';
        echo '<a href="logout.php">Logout</a>';
    }
    echo '</nav></header><main class="container"><h1>'.e($title).'</h1>';
    show_flash();
}
function layout_end(): void { echo '</main><footer>Student Organization Membership Management System</footer></body></html>'; }
