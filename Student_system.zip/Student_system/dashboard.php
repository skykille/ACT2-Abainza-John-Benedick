<?php
require_once __DIR__.'/includes/functions.php'; require_login();
$u=current_user(); $orgs=read_data(ORGS_FILE); $apps=read_data(APPS_FILE); $users=read_data(USERS_FILE);
layout_start('Dashboard');
if($u['role']==='admin'):
?>
<p>Welcome, <?=e($u['name'])?>. Here is an overview of your student organizations.</p>
<div class="stats">
<div class="stat"><strong><?=count($users)?></strong><span>Total accounts</span></div>
<div class="stat"><strong><?=count($orgs)?></strong><span>Organizations</span></div>
<div class="stat"><strong><?=count(array_filter($apps,fn($a)=>$a['status']==='Pending'))?></strong><span>Pending applications</span></div>
<div class="stat"><strong><?=count(array_filter($apps,fn($a)=>$a['status']==='Approved'))?></strong><span>Approved memberships</span></div>
</div>
    
<?php else:
$mine=array_filter($apps,fn($a)=>$a['student_id']===$u['id']);
?>
<p>Welcome, <?=e($u['name'])?>! Browse organizations and manage your membership applications.</p>
<div class="stats">
<div class="stat"><strong><?=count($orgs)?></strong><span>Available organizations</span></div>
<div class="stat"><strong><?=count($mine)?></strong><span>Your applications</span></div>
<div class="stat"><strong><?=count(array_filter($mine,fn($a)=>$a['status']==='Approved'))?></strong><span>Approved memberships</span></div>
</div>
<a class="btn" href="organizations.php">Browse Organizations</a>
<?php endif; layout_end(); ?>
