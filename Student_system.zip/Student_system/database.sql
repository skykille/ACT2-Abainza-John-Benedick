-- Student Organization System database; import this file using phpMyAdmin.
CREATE DATABASE IF NOT EXISTS `student_system` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `student_system`;
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS `users` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(190) NOT NULL,
`email` VARCHAR(190) NOT NULL, `password` VARCHAR(255) NOT NULL, `role` VARCHAR(30) NOT NULL DEFAULT 'student',
`student_id` VARCHAR(80) NOT NULL DEFAULT '', `course` VARCHAR(120) NOT NULL DEFAULT '',
`year_level` VARCHAR(40) NOT NULL DEFAULT '', `created_at` VARCHAR(40) NOT NULL,
PRIMARY KEY (`id`), UNIQUE KEY `uq_users_email` (`email`), UNIQUE KEY `uq_users_student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS `organizations` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `name` VARCHAR(190) NOT NULL, `description` TEXT NOT NULL,
`category` VARCHAR(100) NOT NULL DEFAULT '', `status` VARCHAR(30) NOT NULL DEFAULT 'Active',
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS `applications` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT, `student_id` INT UNSIGNED NOT NULL, `student_name` VARCHAR(190) NOT NULL,
`organization_id` INT UNSIGNED NOT NULL, `organization_name` VARCHAR(190) NOT NULL, `status` VARCHAR(30) NOT NULL DEFAULT 'Pending',
`applied_at` VARCHAR(40) NOT NULL, `reviewed_at` VARCHAR(40) NULL, `admin_note` TEXT NOT NULL,
PRIMARY KEY (`id`), KEY `idx_app_student` (`student_id`), KEY `idx_app_org` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Existing accounts, including their original password hashes.
INSERT INTO `users` (`id`,`name`,`email`,`password`,`role`,`student_id`,`course`,`year_level`,`created_at`) VALUES
(1,'System Administrator','admin@school.edu','$2y$10$HnMucDcRefV0CDQvhA0nLebuWjYBQJfwjozEd.u8krJ19N6C8mXXC','admin','','','','2026-11-02T05:08:03+01:00'),
(2,'John Benedick Abainza','johnbenedickabainza@gmail.com','$2y$10$bSotQcXa3/bS/RtiDoStGueP5j6wHlXsuAsdGolmDm6zjWFAeSrZ6','student','25011086','ACT','2nd Year','2026-11-02T05:18:20+01:00'),
(3,'Alberta','albert@gmail.com','$2y$10$/3PgE.XFYRw72O1QDiZuce7xMjA3iZRsXD8I5Mi04sgtqO9V0tQ/G','student','25011067','ACT','2nd Year','2026-11-03T03:47:56+01:00');

-- Existing organizations.
INSERT INTO `organizations` (`id`,`name`,`description`,`category`,`status`) VALUES
(1,'Information Technology Society','A community for students interested in technology, programming, and innovation.','Academic','Active'),
(2,'Campus Volunteer Organization','Student volunteers supporting campus and community activities.','Service','Active');

-- Existing applications and review statuses.
INSERT INTO `applications` (`id`,`student_id`,`student_name`,`organization_id`,`organization_name`,`status`,`applied_at`,`reviewed_at`,`admin_note`) VALUES
(1,2,'John Benedick Abainza',1,'Information Technology Society','Rejected','2026-11-02T05:18:42+01:00','2026-11-05T13:52:35+01:00',''),
(2,2,'John Benedick Abainza',2,'Campus Volunteer Organization','Rejected','2026-11-02T05:18:53+01:00','2026-11-04T06:53:58+01:00',''),
(3,3,'Alberta',1,'Information Technology Society','Approved','2026-11-03T03:49:44+01:00','2026-11-05T07:41:17+01:00',''),
(4,3,'Alberta',2,'Campus Volunteer Organization','Rejected','2026-11-03T03:49:49+01:00','2026-11-04T06:53:53+01:00',''),
(5,2,'John Benedick Abainza',2,'Campus Volunteer Organization','Pending','2026-11-04T06:54:57+01:00',NULL,''),
(6,2,'John Benedick Abainza',1,'Information Technology Society','Pending','2026-11-04T06:55:04+01:00',NULL,''),
(7,2,'John Benedick Abainza',3,'IT Membership','Rejected','2026-11-05T08:02:47+01:00','2026-11-05T08:03:32+01:00','');

ALTER TABLE `users` AUTO_INCREMENT = 4;
ALTER TABLE `organizations` AUTO_INCREMENT = 3;
ALTER TABLE `applications` AUTO_INCREMENT = 8;
