<?php
require_once __DIR__ . '/includes/functions.php';
$pdo = db();
$counts = [];
foreach (['users','organizations','applications'] as $table) {
    $counts[$table] = (int)$pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
}
layout_start('Database Check');
echo '<div class="panel"><h2>MySQL connection successful</h2><p>Connected to <strong>student_system</strong>.</p><ul>';
foreach ($counts as $table => $count) echo '<li>' . e(ucfirst($table)) . ': ' . e($count) . ' records</li>';
echo '</ul><p><a class="btn" href="dashboard.php">Go to dashboard</a></p></div>';
layout_end();
