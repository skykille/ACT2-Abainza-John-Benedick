<?php
define('APP_NAME', 'Student Organization System');
define('DATA_DIR', dirname(__DIR__) . '/data');
define('USERS_FILE', DATA_DIR . '/users.json');
define('ORGS_FILE', DATA_DIR . '/organizations.json');
define('APPS_FILE', DATA_DIR . '/applications.json');

// XAMPP defaults. Change these if your MySQL credentials differ.
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'student_system');
define('DB_USER', 'root');
define('DB_PASS', '');
