<?php
require_once __DIR__.'/includes/functions.php'; require_role('admin');
$students=array_filter(read_data(USERS_FILE),fn($u)=>$u['role']==='student');
layout_start('Registered Students'); ?>
<div class="panel table-wrap"><table><thead><tr><th>Student ID</th><th>Name</th><th>Email</th><th>Course</th><th>Year</th><th>Registered</th></tr></thead><tbody>
<?php foreach($students as $s): ?><tr><td><?=e($s['student_id'])?></td><td><?=e($s['name'])?></td><td><?=e($s['email'])?></td><td><?=e($s['course'])?></td><td><?=e($s['year_level'])?></td><td><?=e(date('M d, Y',strtotime($s['created_at'])))?></td></tr><?php endforeach; ?>
<?php if(!$students) echo '<tr><td colspan="6">No registered students.</td></tr>'; ?>
</tbody></table></div><?php layout_end(); ?>
