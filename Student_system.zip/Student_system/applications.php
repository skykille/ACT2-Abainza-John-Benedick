<?php
require_once __DIR__.'/includes/auth.php'; require_role('admin');
$apps=read_data(APPS_FILE);
if($_SERVER['REQUEST_METHOD']==='POST') {
    $id=(int)($_POST['id']??0); $status=$_POST['status']??''; $note=trim($_POST['admin_note']??'');
    if(in_array($status,['Approved','Rejected','Pending'])) {
        foreach($apps as &$a) if($a['id']===$id) {$a['status']=$status;$a['admin_note']=$note;$a['reviewed_at']=date('c');}
        unset($a); write_data(APPS_FILE,$apps); set_flash('Application updated.');
    }
    redirect('applications.php');
}
layout_start('Membership Applications'); ?>
<div class="panel table-wrap"><table><thead><tr><th>Student</th><th>Organization</th><th>Applied</th><th>Status</th><th>Review</th></tr></thead><tbody>
<?php foreach($apps as $a): ?><tr><td><?=e($a['student_name'])?></td><td><?=e($a['organization_name'])?></td><td><?=e(date('M d, Y',strtotime($a['applied_at'])))?></td><td><?=e($a['status'])?></td><td><form method="post" class="review"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=e($a['id'])?>"><select name="status"><?php foreach(['Pending','Approved','Rejected'] as $s) echo '<option '.($a['status']===$s?'selected':'').'>'.$s.'</option>'; ?></select><input name="admin_note" placeholder="Optional note" value="<?=e($a['admin_note'])?>"><button class="btn small">Save</button></form></td></tr><?php endforeach; ?>
<?php if(!$apps) echo '<tr><td colspan="5">No applications yet.</td></tr>'; ?>
</tbody></table></div><?php layout_end(); ?>
